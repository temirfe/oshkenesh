<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=oshkenesh',
    'username' => 'oshuser',
    'password' => 'osh85qw',
    'charset' => 'utf8',
];
