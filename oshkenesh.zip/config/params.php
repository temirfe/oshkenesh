<?php

return [
    'adminEmail' => 'admin@collegestatistics.org',
    'supportEmail' => 'support@collegestatistics.org',
    'user.passwordResetTokenExpire' => 3600,
];
